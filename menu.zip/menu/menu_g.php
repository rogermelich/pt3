<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="<?=$ruta?>gestio/menu/stilsMenu.css" rel="stylesheet" type="text/css">
<style>
body, tr, td, p, li { font-family:  verdana; font-size: 10px; }
		hr { color: #355b82; height : 1px; }
		a {color:#355b82; text-decoration:none; }
		a:hover{ font-weight:bold;}
		input { font-family:verdana; font-size:10px; position:absolute; top:0px; right: 0px;
		
		}
body {
	margin-left: 10px;
	margin-top: 5px;
	margin-right: 5px;
	margin-bottom: 5px;
}
</style>
<title>Documento sin t&iacute;tulo</title>
</head>
<body>
Gesti�
</body>
</html>
